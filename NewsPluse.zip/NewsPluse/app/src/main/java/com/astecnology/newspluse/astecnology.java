package com.astecnology.newspluse;

import android.app.Application;

public class astecnology extends Application {
}
