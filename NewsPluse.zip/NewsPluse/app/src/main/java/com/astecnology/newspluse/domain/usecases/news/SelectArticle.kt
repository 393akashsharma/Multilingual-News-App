package com.astecnology.newspluse.domain.usecases.news

import com.astecnology.newspluse.domain.model.Article
import com.astecnology.newspluse.domain.repository.NewsRepository


class SelectArticle(private val newsRepository: NewsRepository) {


    suspend operator fun invoke(url: String): Article? {
        return newsRepository.selectArticle(url)
    }
}