package com.astecnology.newspluse.domain.usecases.news

import com.astecnology.newspluse.domain.model.Article
import com.astecnology.newspluse.domain.repository.NewsRepository
import kotlinx.coroutines.flow.Flow


class SelectArticles(private val newsRepository: NewsRepository) {


    operator fun invoke(): Flow<List<Article>> {
        return newsRepository.selectArticles()
    }
}