package com.astecnology.newspluse.presentation.news_navigator

import androidx.annotation.DrawableRes


data class BottomNavigationItem(@DrawableRes val icon : Int, val text : String)