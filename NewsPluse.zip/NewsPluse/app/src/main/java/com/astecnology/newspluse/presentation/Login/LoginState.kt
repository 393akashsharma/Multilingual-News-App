package com.astecnology.newspluse.presentation.Login


data class LoginState(
    val name :String
)