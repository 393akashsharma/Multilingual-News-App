package com.astecnology.newspluse.domain.usecases.appEntry

import com.astecnology.newspluse.domain.manager.LocalUserManager


class SaveAppEntry(private val localUserManager: LocalUserManager) {


    suspend operator fun invoke() {
        localUserManager.saveAppEntry()
    }
}