package com.astecnology.newspluse.presentation.Login

class LoginViewModel {
}