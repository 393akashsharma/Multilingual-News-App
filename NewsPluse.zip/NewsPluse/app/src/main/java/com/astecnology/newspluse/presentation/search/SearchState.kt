package com.astecnology.newspluse.presentation.search

import androidx.paging.PagingData
import com.astecnology.newspluse.domain.model.Article
import kotlinx.coroutines.flow.Flow


data class SearchState(
    val searchQuery: String = "",
    val articles: Flow<PagingData<Article>>? = null
)