package com.astecnology.newspluse.presentation.onboarding


sealed class OnBoardingEvent {


    object  SaveAppEntry : OnBoardingEvent()

}