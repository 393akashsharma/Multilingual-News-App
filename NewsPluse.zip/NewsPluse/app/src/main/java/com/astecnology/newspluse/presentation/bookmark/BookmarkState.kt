package com.astecnology.newspluse.presentation.bookmark

import com.astecnology.newspluse.domain.model.Article


data class BookmarkState(
    val articles: List<Article> = emptyList()
)