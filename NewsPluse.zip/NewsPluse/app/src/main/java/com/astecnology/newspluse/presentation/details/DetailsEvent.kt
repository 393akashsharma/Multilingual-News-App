package com.astecnology.newspluse.presentation.details

import com.astecnology.newspluse.domain.model.Article


sealed class DetailsEvent {

    data class UpsertDeleteArticle(val article: Article) : DetailsEvent()


    object RemoveSideEvent : DetailsEvent()
}