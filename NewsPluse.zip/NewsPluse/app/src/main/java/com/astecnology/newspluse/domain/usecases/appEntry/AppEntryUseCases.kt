package com.astecnology.newspluse.domain.usecases.appEntry


data class AppEntryUseCases(
    val readAppEntry: ReadAppEntry,
    val saveAppEntry: SaveAppEntry
)