package com.astecnology.newspluse.presentation.Inshort

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding


import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Button

import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow

import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.TextStyle

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.compose.ui.util.lerp
import androidx.paging.compose.LazyPagingItems
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.astecnology.newspluse.R
import com.astecnology.newspluse.domain.model.Article
import com.astecnology.newspluse.presentation.Dimens

import kotlin.math.absoluteValue

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Inshort(
    articles: LazyPagingItems<Article>
) {
    val pagerState = rememberPagerState(pageCount = { articles.itemCount })
    val coroutineScope = rememberCoroutineScope()

    VerticalPager(state = pagerState) { page ->
        Card(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 10.dp)
                .background(Color.Gray)
                .graphicsLayer {
                    val pageOffset = (
                            (pagerState.currentPage - page) + pagerState
                                .currentPageOffsetFraction
                            ).absoluteValue

                    // We animate the alpha, between 50% and 100%
                    alpha = lerp(
                        start = 0.5f,
                        stop = 1f,
                        fraction = 1f - pageOffset.coerceIn(0f, 1f)
                    )
                }
        ) {
            val articleIndex = page % articles.itemCount // Get the index of the article for this page
            val article = articles[articleIndex] // Get the article at the computed index


            article?.let {
                Spacer(modifier = Modifier.height(Dimens.MediumPadding1))
                Text(modifier = Modifier
                    .padding(top=60.dp,start=20.dp,end=5.dp),
                    text = article.title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = colorResource(id = R.color.text_title)
                )

                AsyncImage(
                    model = ImageRequest.Builder(context = LocalContext.current).data(it.urlToImage).build(),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(Dimens.ArticleImageHeight)
                        .padding(10.dp)
                        .clip(MaterialTheme.shapes.medium),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.height(Dimens.MediumPadding1))



                Text(modifier = Modifier
                    .padding(top=10.dp,start=20.dp,end=5.dp),
                    text = article.content,
                    style = TextStyle(
                        fontSize = 20.sp,
                        shadow = Shadow(
                            color = Color.Black
                        )
                    ),
                    color = colorResource(id = R.color.text_title)
                )


            }
        }
    }
}
