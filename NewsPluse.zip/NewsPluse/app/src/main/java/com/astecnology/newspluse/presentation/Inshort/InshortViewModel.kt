package com.astecnology.newspluse.presentation.Inshort

class InshortViewModel {
}

